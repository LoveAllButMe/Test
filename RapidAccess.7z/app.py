from flask import Flask
from flask import Flask, flash, redirect, render_template, request, session, abort, url_for
from flask import Response
import time
import os

app = Flask(__name__)

profile_filename=""
sid_filename=""

@app.route('/')
def home():
 if not session.get('logged_in'):
  return render_template('login.html')
 else:
  return "Hello Boss!"


@app.route("/logout")
def logout():
 session['logged_in'] = False
 return home()

@app.route('/login', methods=['POST'])
def do_admin_login():
 if request.form['password'] == 'password' and request.form['username'] == 'admin':
  session['logged_in'] = True
  return do_upload()
 else:
  flash('wrong password!')
 return home()


def do_upload():
 return render_template('RSAMfiles.html')    

def read_files():
 global profile_filename   
 count=0
 with open(profile_filename, "r+") as file1:
  for line in file1:
   count += 1
   print("Line{}: {}".format(count, line.strip()))
   yield "\nLine{}: {}".format(count, line.strip())
   time.sleep(1)



@app.route("/log_stream", methods=["GET"])
def do_stream():
 return Response(read_files(), mimetype="text/plain", content_type="text/event-stream")

@app.route('/savefile', methods=['POST'])
def do_save():
 profile_filenameobj=request.files['profile']
 sid_filenameobj=request.files['sid']
 global profile_filename
 profile_filename = profile_filenameobj.filename
 global sid_filename 
 sid_filename = sid_filenameobj.filename
 profile_filenameobj.save(profile_filenameobj.filename)
 sid_filenameobj.save(sid_filenameobj.filename)
 return do_stream()

def do_success():
 return render_template('success.html')    

if __name__ == "__main__":
 app.secret_key = os.urandom(12)
 app.run()